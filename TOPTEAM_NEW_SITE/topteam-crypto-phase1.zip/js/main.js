/**
 * TOPTEAM Core Application Logic
 * Language switcher, dynamic config injection, mobile drawer, scroll animations
 */

document.addEventListener('DOMContentLoaded', () => {
  // Current active language (default: Arabic 'ar')
  let currentLang = 'ar';

  // DOM Elements
  const headerSticky = document.querySelector('.header-sticky');
  const langDropdown = document.querySelector('.lang-dropdown-wrapper');
  const langBtn = document.querySelector('.lang-btn');
  const currentLangLabel = document.querySelector('.current-lang-label');
  const langItems = document.querySelectorAll('.lang-item');
  const mobileToggle = document.querySelector('.mobile-menu-toggle');
  const mobileDrawer = document.querySelector('.mobile-drawer');
  const drawerBackdrop = document.querySelector('.drawer-backdrop');
  const drawerClose = document.querySelector('.drawer-close');
  const drawerLinks = document.querySelectorAll('.drawer-nav-link');
  const whatsappBtn = document.querySelector('#floatingWhatsappBtn');
  const startMiningButtons = document.querySelectorAll('.btn-referral-start');

  // ==========================================
  // 1. Injected Links from config.js
  // ==========================================
  function applyConfigLinks() {
    if (typeof TOPTEAM_CONFIG === 'undefined') return;

    // Referral Buttons
    startMiningButtons.forEach(btn => {
      if (TOPTEAM_CONFIG.referral && TOPTEAM_CONFIG.referral.startMiningUrl) {
        btn.setAttribute('href', TOPTEAM_CONFIG.referral.startMiningUrl);
        btn.setAttribute('target', '_blank');
        btn.setAttribute('rel', 'noopener noreferrer');
      }
    });

    // WhatsApp Floating Button
    if (whatsappBtn && TOPTEAM_CONFIG.whatsapp) {
      const waLink = TOPTEAM_CONFIG.whatsapp.getLink ? TOPTEAM_CONFIG.whatsapp.getLink() : `https://wa.me/${TOPTEAM_CONFIG.whatsapp.phoneNumber}`;
      whatsappBtn.setAttribute('href', waLink);
      whatsappBtn.setAttribute('target', '_blank');
      whatsappBtn.setAttribute('rel', 'noopener noreferrer');
    }
  }

  // ==========================================
  // 2. Language Switcher Engine
  // ==========================================
  function setLanguage(lang) {
    if (!TRANSLATIONS[lang]) return;
    currentLang = lang;
    const t = TRANSLATIONS[lang];

    // Update HTML dir and lang attributes
    document.documentElement.setAttribute('dir', t.dir);
    document.documentElement.setAttribute('lang', lang);

    // Update Current Lang Label in button
    if (currentLangLabel) {
      currentLangLabel.textContent = t.langName;
    }

    // Update Active class in dropdown
    langItems.forEach(item => {
      if (item.getAttribute('data-lang') === lang) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });

    // Translate all elements with [data-i18n]
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const keyPath = el.getAttribute('data-i18n').split('.');
      let val = t;
      for (const key of keyPath) {
        if (val && val[key] !== undefined) {
          val = val[key];
        } else {
          val = null;
          break;
        }
      }
      if (val !== null) {
        el.textContent = val;
      }
    });

    // Close dropdown
    if (langDropdown) {
      langDropdown.classList.remove('open');
    }

    // Save preference
    localStorage.setItem('topteam_lang', lang);
  }

  // Language Dropdown Toggle
  if (langBtn && langDropdown) {
    langBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      langDropdown.classList.toggle('open');
    });

    // Language Items Click
    langItems.forEach(item => {
      item.addEventListener('click', () => {
        const selectedLang = item.getAttribute('data-lang');
        setLanguage(selectedLang);
      });
    });

    // Close on outside click
    document.addEventListener('click', () => {
      langDropdown.classList.remove('open');
    });
  }

  // ==========================================
  // 3. Header Scroll Effect
  // ==========================================
  function handleScroll() {
    if (window.scrollY > 40) {
      headerSticky.classList.add('scrolled');
    } else {
      headerSticky.classList.remove('scrolled');
    }
  }
  window.addEventListener('scroll', handleScroll, { passive: true });

  // ==========================================
  // 4. Mobile Drawer Navigation
  // ==========================================
  function openDrawer() {
    mobileDrawer.classList.add('open');
    drawerBackdrop.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeDrawer() {
    mobileDrawer.classList.remove('open');
    drawerBackdrop.classList.remove('open');
    document.body.style.overflow = '';
  }

  if (mobileToggle) mobileToggle.addEventListener('click', openDrawer);
  if (drawerClose) drawerClose.addEventListener('click', closeDrawer);
  if (drawerBackdrop) drawerBackdrop.addEventListener('click', closeDrawer);

  drawerLinks.forEach(link => {
    link.addEventListener('click', () => {
      closeDrawer();
    });
  });

  // ==========================================
  // 5. Smooth Scroll for in-page anchors
  // ==========================================
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const targetId = this.getAttribute('href');
      if (targetId && targetId !== '#') {
        const targetEl = document.querySelector(targetId);
        if (targetEl) {
          e.preventDefault();
          const headerOffset = 80;
          const elementPosition = targetEl.getBoundingClientRect().top;
          const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

          window.scrollTo({
            top: offsetPosition,
            behavior: 'smooth'
          });
        }
      }
    });
  });

  // Initialize
  applyConfigLinks();

  // Load stored language or default to Arabic
  const savedLang = localStorage.getItem('topteam_lang') || 'ar';
  setLanguage(savedLang);
});
