/**
 * TOPTEAM Global Configuration
 * ===================================================
 * يمكنك تعديل جميع الروابط، أرقام التواصل، وروابط الإحالة
 * بسهولة من هذا الملف دون الحاجة لتعديل كود الـ HTML.
 */

const TOPTEAM_CONFIG = {
  // اسم وهوية العلامة
  brand: {
    name: "TOPTEAM",
    tagline: "Crypto & Blockchain Ecosystem",
    establishedYear: 2011,
    yearsOfExperience: 13,
  },

  // روابط الإحالة والتسجيل (يمكنك استبدالها بروابطك الخاصة في أي وقت)
  referral: {
    // زر ابدأ تعدين البيتكوين الرئيسي
    startMiningUrl: "https://hashnet.example.com/register?ref=TOPTEAM",
    // زر سجل الآن في قسم HashNet
    hashnetRegisterUrl: "https://hashnet.example.com/join?ref=TOPTEAM",
    // روابط باقات التعدين المختلفة (سيتم تفعيلها في قسم الباقات)
    packages: {
      plan150: "https://hashnet.example.com/buy/150?ref=TOPTEAM",
      plan500: "https://hashnet.example.com/buy/500?ref=TOPTEAM",
      plan1000: "https://hashnet.example.com/buy/1000?ref=TOPTEAM",
      plan2500: "https://hashnet.example.com/buy/2500?ref=TOPTEAM",
      plan5000: "https://hashnet.example.com/buy/5000?ref=TOPTEAM",
    }
  },

  // إعدادات زر واتساب العائم والتواصل
  whatsapp: {
    phoneNumber: "212600000000", // استبدل برقم هاتفك مع الرمز الدولي (بدون + أو فراغات)
    defaultMessage: "مرحباً TOPTEAM، أود الاستفسار عن تفاصيل تعدين العملات الرقمية ومشروع HashNet.",
    // دالة للحصول على رابط واتساب المباشر
    getLink: function() {
      return `https://wa.me/${this.phoneNumber}?text=${encodeURIComponent(this.defaultMessage)}`;
    }
  },

  // وسائل التواصل الاجتماعي والبريد الإلكتروني
  contact: {
    email: "contact@topteam-crypto.com",
    telegram: "https://t.me/TOPTEAM_Official",
    twitter: "https://x.com/TOPTEAM_Crypto",
    youtube: "https://youtube.com/@TOPTEAM_Crypto",
    instagram: "https://instagram.com/TOPTEAM_Crypto"
  },

  // إعدادات واجهة البيانات الحية (جاهز للمراحل القادمة)
  cryptoApi: {
    provider: "coingecko",
    apiKey: "", // ضع مفتاح API هنا إذا لزم الأمر لاحقاً
    refreshIntervalMs: 30000
  }
};

// إتاحة الإعدادات عالمياً
window.TOPTEAM_CONFIG = TOPTEAM_CONFIG;
