/**
 * TOPTEAM Multilingual Translations Dictionary
 * Languages: Arabic (ar), English (en), French (fr), Spanish (es)
 */

const TRANSLATIONS = {
  ar: {
    dir: "rtl",
    langName: "العربية",
    nav: {
      home: "الرئيسية",
      crypto: "العملات الرقمية",
      blockchain: "البلوكشين",
      mining: "تعدين العملات",
      projects: "المشاريع",
      contact: "تواصل معنا",
      startMining: "ابدأ تعدين البيتكوين"
    },
    hero: {
      badge: "الجيل الجديد لتعدين العملات الرقمية والبلوكشين",
      titleStart: "اكتشف عالم العملات الرقمية مع",
      brandName: "TOPTEAM",
      description: "بخبرة تتجاوز 13 عامًا في عالم العملات الرقمية والتعدين وتقنية البلوكشين، نساعدك على فهم هذا المجال، واكتشاف أحدث المشاريع والفرص الرقمية، ومتابعة أهم التطورات في عالم العملات الرقمية.",
      btnPrimary: "ابدأ تعدين البيتكوين",
      btnSecondary: "اكتشف عالم العملات الرقمية",
      cardBadge: "عقدة تعدين نشطة 24/7",
      stat1Label: "سنوات خبرة في الكريبتو",
      stat1Val: "+13 عام",
      stat2Label: "كفاءة البنية التحتية",
      stat2Val: "99.9%",
      stat3Label: "العملات المدعومة",
      stat3Val: "6 عملات",
      liveStatus: "متصل بالشبكة العالمية",
      nodeSecurity: "حماية وتشفير عالي المستوى"
    },
    intro: {
      badge: "من نحن ورؤيتنا",
      title: "خبرة، معرفة، واستكشاف للفرص الرقمية",
      description: "نركز على تبسيط عالم العملات الرقمية والتعدين والبلوكشين، ومساعدة المهتمين على فهم هذا المجال بصورة أوضح، مع متابعة المشاريع والتطورات الجديدة المرتبطة به.",
      card1Title: "تبسيط عالم الكريبتو",
      card1Desc: "تحويل المفاهيم التقنية المعقدة في البلوكشين والتعدين إلى خطوات واضحة ومفهومة تناسب الجميع.",
      card2Title: "استكشاف الفرص والمشاريع",
      card2Desc: "دراسة ومتابعة أحدث مشاريع التعدين السحابي والبنية التحتية ذات الموثوقية العالية.",
      card3Title: "خبرة تراكمية تفوق 13 عامًا",
      card3Desc: "رؤية متعمقة مبنية على مواكبة تطور البيتكوين وتقنيات السجلات الموزعة منذ بداياتها الأولى.",
      card4Title: "بنية تحتية ومتابعة تقنية",
      card4Desc: "الاطلاع على أحدث أجهزة التعدين ومراكز البيانات العالمية ومعايير استهلاك الطاقة المستدامة."
    },
    stats: {
      experience: "سنوات من الخبرة والريادة",
      currencies: "عملات رئيسية قابلة للتعدين",
      transparency: "شفافية ومصداقية كاملة",
      support: "توجيه واستشارات مستمرة"
    },
    whatsapp: {
      tooltip: "تحدث معنا عبر WhatsApp",
      status: "متواجدون للرد عليك"
    }
  },

  en: {
    dir: "ltr",
    langName: "English",
    nav: {
      home: "Home",
      crypto: "Cryptocurrencies",
      blockchain: "Blockchain",
      mining: "Crypto Mining",
      projects: "Projects",
      contact: "Contact Us",
      startMining: "Start Bitcoin Mining"
    },
    hero: {
      badge: "Next Generation Crypto Mining & Blockchain",
      titleStart: "Discover the World of Crypto with",
      brandName: "TOPTEAM",
      description: "With over 13 years of experience in the crypto, mining, and blockchain space, we help you master the industry, discover top digital opportunities, and stay ahead of the crypto revolution.",
      btnPrimary: "Start Bitcoin Mining",
      btnSecondary: "Explore Crypto World",
      cardBadge: "Active Mining Node 24/7",
      stat1Label: "Years in Crypto",
      stat1Val: "13+ Years",
      stat2Label: "Infrastructure Uptime",
      stat2Val: "99.9%",
      stat3Label: "Supported Assets",
      stat3Val: "6 Assets",
      liveStatus: "Connected to Global Network",
      nodeSecurity: "Enterprise-grade Encryption"
    },
    intro: {
      badge: "About Us & Our Vision",
      title: "Experience, Knowledge & Digital Discovery",
      description: "We focus on simplifying cryptocurrency, mining, and blockchain technologies, helping enthusiasts navigate the landscape with clarity while tracking breakthrough developments.",
      card1Title: "Demystifying Crypto",
      card1Desc: "Transforming complex blockchain and mining mechanics into intuitive, accessible knowledge for everyone.",
      card2Title: "Vetting Leading Projects",
      card2Desc: "Carefully analyzing and tracking top-tier cloud mining infrastructure and emerging high-value protocols.",
      card3Title: "13+ Years of Field Mastery",
      card3Desc: "Deep institutional insight built through navigating Bitcoin and distributed ledger evolution since early days.",
      card4Title: "Infrastructure & Tech Oversight",
      card4Desc: "Tracking cutting-edge mining rigs, Tier-3 data centers, and modern energy-efficient operations."
    },
    stats: {
      experience: "Years of Industry Leadership",
      currencies: "Major Mineable Cryptos",
      transparency: "Full Transparency & Trust",
      support: "Continuous Guidance & Support"
    },
    whatsapp: {
      tooltip: "Chat with us on WhatsApp",
      status: "Online & ready to assist"
    }
  },

  fr: {
    dir: "ltr",
    langName: "Français",
    nav: {
      home: "Accueil",
      crypto: "Cryptomonnaies",
      blockchain: "Blockchain",
      mining: "Minage Crypto",
      projects: "Projets",
      contact: "Contact",
      startMining: "Démarrer le Minage Bitcoin"
    },
    hero: {
      badge: "Nouvelle Génération de Minage Crypto & Blockchain",
      titleStart: "Découvrez le monde des cryptos avec",
      brandName: "TOPTEAM",
      description: "Avec plus de 13 ans d'expérience dans les cryptomonnaies, le minage et la blockchain, nous vous guidons pour maîtriser ce domaine et découvrir les meilleures opportunités numériques.",
      btnPrimary: "Démarrer le Minage Bitcoin",
      btnSecondary: "Explorer l'Univers Crypto",
      cardBadge: "Nœud de minage actif 24/7",
      stat1Label: "Années d'expérience",
      stat1Val: "+13 Ans",
      stat2Label: "Disponibilité",
      stat2Val: "99.9%",
      stat3Label: "Actifs minables",
      stat3Val: "6 Actifs",
      liveStatus: "Connecté au Réseau Mondial",
      nodeSecurity: "Chiffrement Haut Niveau"
    },
    intro: {
      badge: "Notre Vision",
      title: "Expérience, Savoir et Exploration Digitale",
      description: "Nous simplifions le monde des cryptos, du minage et de la blockchain pour vous offrir une vision limpide des innovations et des projets émergents.",
      card1Title: "Simplification Technologique",
      card1Desc: "Transformer la complexité de la blockchain en étapes claires et accessibles à tous.",
      card2Title: "Sélection de Projets Élite",
      card2Desc: "Veille approfondie sur les infrastructures de pointe et le minage haute performance.",
      card3Title: "13+ Ans de Savoir-Faire",
      card3Desc: "Une expertise éprouvée depuis les débuts historiques du Bitcoin et des registres distribués.",
      card4Title: "Infrastructures Avancées",
      card4Desc: "Suivi des derniers équipements de minage (Antminer) et des datacenters éco-efficients."
    },
    stats: {
      experience: "Années d'Expertise Crypto",
      currencies: "Grandes Devises Minables",
      transparency: "Transparence et Clarté",
      support: "Accompagnement Continu"
    },
    whatsapp: {
      tooltip: "Discutez avec nous sur WhatsApp",
      status: "En ligne pour vous répondre"
    }
  },

  es: {
    dir: "ltr",
    langName: "Español",
    nav: {
      home: "Inicio",
      crypto: "Criptomonedas",
      blockchain: "Blockchain",
      mining: "Minería Crypto",
      projects: "Proyectos",
      contact: "Contacto",
      startMining: "Comenzar Minería Bitcoin"
    },
    hero: {
      badge: "Nueva Generación de Minería Crypto y Blockchain",
      titleStart: "Descubre el mundo de las criptomonedas con",
      brandName: "TOPTEAM",
      description: "Con más de 13 años de experiencia en el mundo de las criptomonedas, minería y blockchain, te ayudamos a comprender este sector y descubrir las mejores oportunidades digitales.",
      btnPrimary: "Comenzar Minería Bitcoin",
      btnSecondary: "Explorar Mundo Crypto",
      cardBadge: "Nodo de Minería Activo 24/7",
      stat1Label: "Años de experiencia",
      stat1Val: "+13 Años",
      stat2Label: "Disponibilidad",
      stat2Val: "99.9%",
      stat3Label: "Monedas minables",
      stat3Val: "6 Activos",
      liveStatus: "Conectado a la Red Global",
      nodeSecurity: "Seguridad de Grado Empresarial"
    },
    intro: {
      badge: "Nuestra Visión",
      title: "Experiencia, Conocimiento y Oportunidades Digitales",
      description: "Nos enfocamos en simplificar el universo crypto, la minería y blockchain, ayudándote a entender este ecosistema y aprovechar los mejores proyectos.",
      card1Title: "Simplificación Crypto",
      card1Desc: "Convertimos la complejidad técnica de blockchain en conceptos claros y prácticos.",
      card2Title: "Proyectos Destacados",
      card2Desc: "Análisis riguroso de infraestructuras líderes y soluciones de minería en la nube.",
      card3Title: "Más de 13 Años de Trayectoria",
      card3Desc: "Perspectiva sólida nacida de seguir la evolución de Bitcoin desde sus inicios.",
      card4Title: "Infraestructura y Tecnología",
      card4Desc: "Supervisión de equipos de última generación (Antminer) y centros de datos eficientes."
    },
    stats: {
      experience: "Años de Liderazgo Crypto",
      currencies: "Criptomonedas Minables",
      transparency: "Transparencia Total",
      support: "Soporte y Asesoría Constante"
    },
    whatsapp: {
      tooltip: "Chatea con nosotros por WhatsApp",
      status: "Disponible para atenderte"
    }
  }
};

// إتاحة القاموس عالمياً
window.TOPTEAM_TRANSLATIONS = TRANSLATIONS;
